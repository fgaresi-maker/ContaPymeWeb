# ContaPyme (sitio web)

Sitio estático de ContaPyme (contapyme.potenciamostupyme.tech) con el asistente Botipyme.

- `src/index.html` y `src/i18n.js`: el sitio (ES / EN / PT).
- `src/ptp-chat.js`: el círculo de chat de Botipyme.
- `api/chat.js`: función de Vercel que responde con Claude. Necesita la variable de entorno `ANTHROPIC_API_KEY`.

En Vercel el directorio de salida es `src`.
