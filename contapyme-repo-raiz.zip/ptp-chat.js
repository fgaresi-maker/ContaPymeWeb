// Widget de chat (ES / EN / PT). Agregar en cada página:  <script src="/ptp-chat.js" defer></script>
// Idioma inicial: window.PTP_LANG, o el atributo lang de <html>, o el idioma del navegador.
(function () {
  var T = {"es": {"name": "Botipyme ContaPyme", "greet": "¡Hola! Soy Botipyme, el asistente de ContaPyme. Preguntame por funciones, planes, precios o cómo pedir una demo."}, "en": {"name": "Botipyme ContaPyme", "greet": "Hi! I'm Botipyme, the ContaPyme assistant. Ask me about features, plans, prices or how to request a demo."}, "pt": {"name": "Botipyme ContaPyme", "greet": "Olá! Sou o Botipyme, assistente do ContaPyme. Pergunte sobre funções, planos, preços ou como pedir uma demo."}}, UI = {"es": {"ph": "Escribí tu consulta...", "send": "Enviar", "typing": "Escribiendo...", "err": "No pude responder ahora. Escribile a fgaresi@gmail.com.", "na": "El asistente no está disponible en esta vista.", "open": "Abrir chat"}, "en": {"ph": "Type your question...", "send": "Send", "typing": "Typing...", "err": "I couldn't answer right now. Email fgaresi@gmail.com.", "na": "The assistant is not available in this view.", "open": "Open chat"}, "pt": {"ph": "Escreva sua dúvida...", "send": "Enviar", "typing": "Digitando...", "err": "Não consegui responder agora. Escreva para fgaresi@gmail.com.", "na": "O assistente não está disponível nesta visualização.", "open": "Abrir chat"}}, L = "es", history = [];
  var pref = String(window.PTP_LANG || document.documentElement.lang || navigator.language || "es").slice(0, 2).toLowerCase();
  if (T[pref]) L = pref;
  var css = `
  #ptp-btn{position:fixed;right:16px;top:100px;width:52px;height:52px;border-radius:50%;border:0;background:#0f4c81;color:#fff;font-size:24px;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.25);z-index:9999}
  #ptp-box{position:fixed;right:16px;top:160px;width:340px;max-width:calc(100vw - 32px);height:480px;max-height:calc(100vh - 176px);background:#fff;color:#1b2430;border-radius:14px;box-shadow:0 10px 40px rgba(0,0,0,.28);display:none;flex-direction:column;overflow:hidden;font:14px/1.45 system-ui,sans-serif;z-index:9999}
  #ptp-box.open{display:flex}
  @media (max-width:640px){#ptp-btn{top:170px}#ptp-box{top:230px;max-height:calc(100vh - 246px)}}
  #ptp-head{background:#0f4c81;color:#fff;padding:10px 12px;font-weight:600;display:flex;align-items:center;gap:8px}
  #ptp-title{flex:1;min-width:0}
  #ptp-lang{display:flex;gap:2px}
  #ptp-lang button{border:0;background:rgba(255,255,255,.15);color:#fff;border-radius:6px;padding:3px 7px;font:600 11px system-ui;cursor:pointer}
  #ptp-lang button.on{background:#fff;color:#0f4c81}
  #ptp-msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px;background:#f4f7fa}
  .ptp-m{max-width:85%;padding:8px 11px;border-radius:12px;white-space:pre-wrap;overflow-wrap:anywhere}
  .ptp-b{background:#fff;border:1px solid #dde4ec;align-self:flex-start}
  .ptp-u{background:#0f4c81;color:#fff;align-self:flex-end}
  #ptp-form{display:flex;gap:6px;padding:10px;border-top:1px solid #dde4ec;background:#fff}
  #ptp-in{flex:1;min-width:0;border:1px solid #c5cfda;border-radius:8px;padding:8px 10px;font:inherit;color:#1b2430;background:#fff}
  #ptp-send{border:0;background:#0f4c81;color:#fff;border-radius:8px;padding:0 14px;cursor:pointer;font:inherit}`;
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
  var btn = document.createElement("button"); btn.id = "ptp-btn"; btn.textContent = "\uD83D\uDCAC";
  var box = document.createElement("div"); box.id = "ptp-box";
  box.innerHTML = '<div id="ptp-head"><span id="ptp-title"></span><span id="ptp-lang"><button data-l="es">ES</button><button data-l="en">EN</button><button data-l="pt">PT</button></span></div><div id="ptp-msgs"></div>' +
    '<form id="ptp-form"><input id="ptp-in" autocomplete="off"><button id="ptp-send"></button></form>';
  document.body.appendChild(btn); document.body.appendChild(box);
  var msgs = box.querySelector("#ptp-msgs"), form = box.querySelector("#ptp-form"), input = box.querySelector("#ptp-in"), sendB = box.querySelector("#ptp-send");
  function add(text, who) {
    var d = document.createElement("div"); d.className = "ptp-m " + (who === "u" ? "ptp-u" : "ptp-b");
    d.textContent = text; msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight; return d;
  }
  function render() {
    box.querySelector("#ptp-title").textContent = T[L].name; input.placeholder = UI[L].ph; sendB.textContent = UI[L].send; btn.setAttribute("aria-label", UI[L].open);
    Array.prototype.forEach.call(box.querySelectorAll("#ptp-lang button"), function (b) { b.className = b.getAttribute("data-l") === L ? "on" : ""; });
    msgs.textContent = ""; history = []; add(T[L].greet, "b");
  }
  box.querySelector("#ptp-lang").onclick = function (e) { var l = e.target.getAttribute && e.target.getAttribute("data-l"); if (l && l !== L) { L = l; render(); } };
  btn.onclick = function () { box.classList.toggle("open"); if (box.classList.contains("open")) input.focus(); };
  form.onsubmit = async function (e) {
    e.preventDefault();
    var t = input.value.trim(); if (!t) return;
    input.value = ""; add(t, "u"); history.push({ role: "user", content: t });
    var w = add(UI[L].typing, "b");
    try {
      var r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: history, lang: L }) });
      var j = await r.json();
      if (!r.ok || !j.reply) throw new Error();
      w.textContent = j.reply; history.push({ role: "assistant", content: j.reply });
    } catch (err) { w.textContent = UI[L].err; history.pop(); }
    msgs.scrollTop = msgs.scrollHeight;
  };
  new MutationObserver(function () { var l = String(document.documentElement.lang || "").slice(0, 2).toLowerCase(); if (T[l] && l !== L) { L = l; render(); } }).observe(document.documentElement, { attributes: true, attributeFilter: ["lang"] });
  render();
})();
